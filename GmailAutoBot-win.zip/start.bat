@echo off
chcp 65001 >nul
title GmailAutoBot
cd /d "%~dp0"

echo === GmailAutoBot ===
if not exist config.txt (
    copy config.example.txt config.txt
    echo [!] config.txt создан из шаблона — заполни токены в панели
)

rem Снимаем виндовую метку "скачан из интернета" с exe — автоматически
powershell -NoProfile -Command "Unblock-File -Path '.\GmailAutoBot.exe'" >nul 2>&1

echo Запускаю софт (не закрывай это окно)...
start /b "" GmailAutoBot.exe
echo Жду панель (до 60 сек)...
set /a tries=0
:waitloop
timeout /t 2 /nobreak >nul
curl -s -o nul -m 2 http://127.0.0.1:8000/health
if %errorlevel%==0 goto up
set /a tries+=1
if %tries% lss 30 goto waitloop
echo.
echo [!] Панель не поднялась за 60 сек. Смотрим:
echo     1. Появилось СИНЕЕ окно Windows? Жми "Подробнее" -^> "Выполнить в любом
echo        случае". Это нормальная защита от незнакомых программ, один раз.
echo     2. Антивирус удалил exe? Добавь папку в исключения антивируса.
echo     3. VPN включён? Выключи и запусти start.bat заново.
echo.
pause
exit /b 1
:up
echo Панель жива! Открываю браузер...
start "" http://127.0.0.1:8000/panel
echo Готово. Это окно можно закрыть.
pause
