@echo off
title GmailAutoBot
cd /d "%~dp0"

echo === GmailAutoBot ===

if not exist config.txt (
    copy config.example.txt config.txt >nul
    echo [i] config.txt created from template - fill tokens in the panel
)

powershell -NoProfile -ExecutionPolicy Bypass -Command "Unblock-File -Path '.\GmailAutoBot.exe'" >nul 2>&1

echo Starting GmailAutoBot in a separate window...
start "GmailAutoBot" GmailAutoBot.exe
echo Waiting for the panel (up to 60 sec)...

set TRIES=0
:waitloop
timeout /t 2 /nobreak >nul
powershell -NoProfile -Command "try{$c=New-Object Net.Sockets.TcpClient;$c.Connect('127.0.0.1',8000);$c.Close();exit 0}catch{exit 1}" >nul 2>&1
if not errorlevel 1 goto up
set /a TRIES+=1
if %TRIES% lss 30 goto waitloop

echo.
echo [i] Panel did not start in 60 sec. Check:
echo      1) Blue SmartScreen window? Click "More info" then "Run anyway".
echo      2) Antivirus removed the exe? Add this folder to antivirus exclusions.
echo      3) VPN is on? Turn it off, then run start.bat again.
echo.
pause
exit /b 1

:up
echo Panel is up. Opening browser...
start "" http://127.0.0.1:8000/panel
echo Done. You can close this window.
pause
