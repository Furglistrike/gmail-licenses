@echo off
chcp 65001 >nul
title GmailAutoBot
cd /d "%~dp0"

echo === GmailAutoBot ===
echo панель: http://127.0.0.1:8000/panel
echo (для рассылки: запусти main в отдельном окне)

if not exist config.txt (
    copy config.example.txt config.txt
    echo.
    echo [!] config.txt создан из шаблона — заполни токены в панели (http://127.0.0.1:8000/panel)
)

start "" http://127.0.0.1:8000/panel
GmailAutoBot.exe
pause
