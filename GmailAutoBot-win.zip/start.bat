@echo off
chcp 65001 >nul
title GmailAutoBot
cd /d "%~dp0"

echo === GmailAutoBot ===
if not exist config.txt (
    copy config.example.txt config.txt
    echo [!] config.txt создан из шаблона — заполни токены в панели
)

echo Запускаю софт (не закрывай это окно)...
start /b "" GmailAutoBot.exe
echo Жду панель (до 60 сек)...
set /a tries=0
:waitloop
timeout /t 2 /nobreak >nul
curl -s -o nul -m 2 http://127.0.0.1:8000/health
if %errorlevel%==0 goto up
set /a tries+=1
if %tries% lss 30 goto waitloop
echo.
echo [!] Панель не поднялась за 60 сек. Возможные причины:
echo     - Windows показал синее окно SmartScreen при запуске exe: нажми
echo       "Подробнее" -^> "Выполнить в любом случае" и запусти заново
echo     - Антивирус удалил exe: добавь папку в исключения
echo     - VPN блокирует проверку лицензии: выключи VPN и запусти заново
echo     - Правый клик на GmailAutoBot.exe -^> Свойства -^> галка "Разблокировать"
echo.
pause
exit /b 1
:up
echo Панель жива! Открываю браузер...
start "" http://127.0.0.1:8000/panel
echo Готово. Это окно можно закрыть.
pause
